package dekha.mvptrial.Model

import com.google.gson.annotations.SerializedName

data class GeneralResponse <T>(
    @field: SerializedName("status")
    val status : String,
    @field: SerializedName("data")
    val data : Student,
    @field: SerializedName("error")
    val error : ErrorResponse?)