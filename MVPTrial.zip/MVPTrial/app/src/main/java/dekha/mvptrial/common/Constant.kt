package dekha.mvptrial.common

object Constant{
    const val STUDENT = "student"
}