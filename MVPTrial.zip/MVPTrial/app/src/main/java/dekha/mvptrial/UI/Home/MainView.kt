package dekha.mvptrial.UI.Home

import  dekha.mvptrial.Model.Student

interface MainView{
    fun showStudents(results: List<Student>)
    fun onError(message: String)
    fun onDeleteStudent(student: Student, isSuccess: Boolean, message: String)
    fun showProgress(show: Boolean)
}