package dekha.mvptrial.UI.Home

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.app.AlertDialog
import android.support.v7.widget.LinearLayoutManager
import android.view.Menu
import android.view.MenuItem
import android.view.View
import dekha.mvptrial.Model.Student
import dekha.mvptrial.R
import dekha.mvptrial.UI.newStudent.FormStudent
import dekha.mvptrial.common.Constant
import dekha.mvptrial.common.toast
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity(), MainView {
    private val presenter = MainPresenter(this)
    private val studentList = mutableListOf<Student>()
    private val studentAdapter = StudentAdapter(studentList, this::onClick, this::onLongClick)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        setupView()
    }

    override fun onResume() {
        super.onResume()
        presenter.getStudents()
    }

    private fun setupView() {
        this.title = "MVP Example"
        rvStudentList.run {
            layoutManager = LinearLayoutManager(context)
            adapter = studentAdapter
        }
        swipeRefresh.setOnRefreshListener{
            presenter.getStudents()
            swipeRefresh.isRefreshing= false
        }
    }

    private fun onLongClick(student: Student) {
        //ketika item di recycler view di klik tahan/lama
        val option : Array<String> = arrayOf("Edit", "Delete")
        AlertDialog.Builder(this)
            .setItems(option) { dialog, which ->
                when (which) {
                    0 -> updateData(student) //edit
                    1 -> askForDelete(student)//hapus, bisa pake else
                }
                dialog.dismiss()
            }
            .show()
    }

    private fun updateData(student: Student) {
        val intent = Intent(this, FormStudent::class.java)
        intent.putExtra(Constant.STUDENT, student)
        startActivity(intent)
    }

    private fun askForDelete(student: Student) {
        AlertDialog.Builder(this)
            .setTitle("Delete Data")
            .setMessage("Are u sure to delete ${student.name} data?")
            .setPositiveButton("No"){dialog, which ->
                dialog.dismiss()
            }
            .setNegativeButton("Yes"){dialog, which ->
                presenter.deleteStudent(student)
            }
            .show()

    }

    private fun onClick(student: Student) {

    }

    override fun showStudents(results: List<Student>) {
        studentList.clear()
        studentList.addAll(results.sortedByDescending { it.id })
        studentAdapter.notifyDataSetChanged()
    }
    override fun onError(message: String) {
        toast(message)
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
       menuInflater.inflate(R.menu.menu_new_student, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem?): Boolean {
        if(item?.itemId== R.id.newStudent) {
            startActivity(Intent(this, FormStudent::class.java))
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onDeleteStudent(student: Student, isSuccess: Boolean, message: String){
        if(isSuccess){
            studentList.remove(student)
            studentAdapter.notifyDataSetChanged()
        }
        toast(message)
    }

    override fun showProgress(show: Boolean) {
        if(show){
            progress.visibility= View.VISIBLE
        }
        else {
            progress.visibility= View.GONE
        }
    }

}
