package dekha.mvptrial

import android.app.Application
import dekha.mvptrial.Network.ApiServices
import dekha.mvptrial.Network.NetworkConfig

class BinarMvpApp : Application() {

    companion object {
        lateinit var api: ApiServices
    }

    override fun onCreate() {
        super.onCreate()

        api = NetworkConfig.getRetrofit().create(ApiServices::class.java)
    }
}