package dekha.mvptrial.Network

import dekha.mvptrial.Model.GeneralResponse
import dekha.mvptrial.Model.Student
import dekha.mvptrial.Model.StudentResponse
import retrofit2.Call
import retrofit2.http.*

interface ApiServices {
    @GET("api/v1/student/all")
    fun getAllStudents(): Call<StudentResponse>

    @Headers("Content-Type: application/json")
    @POST("api/v1/student/")
    fun newStudent(@Body studentMap: Map<String, String>): Call<GeneralResponse<Student>>

    @DELETE("api/v1/student/{studentId}")
    fun deleteStudent(@Path("studentId") id: Int): Call<GeneralResponse<Student>>

    @PUT("api/v1/student/{id}")
    fun editStudent(
        @Path("id") studentId: Int,
        @Body map: Map<String, String>
    ): Call<GeneralResponse<Student>>
}