package dekha.mvptrial.UI.Home

import dekha.mvptrial.BinarMvpApp
import dekha.mvptrial.Model.Student
import dekha.mvptrial.Model.StudentResponse
import dekha.mvptrial.Network.ApiServices
import dekha.mvptrial.common.execute
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainPresenter(private val view: MainView) {

    private val apiServices: ApiServices by lazy { BinarMvpApp.api }

    fun getStudents() {
        view.showProgress(true)
        apiServices.getAllStudents()
            .execute(view::onError) { response ->
                view.showProgress(false)
                if (response != null) {
                    response.data?.let { studentList ->
                        view.showStudents(studentList)
                    }
                } else {
                    view.onError("Error : gagal memuat data")
                }
            }
    }
    fun deleteStudent(student: Student) {
        view.showProgress(true)
        apiServices.deleteStudent(student.id)
            .execute({
                view.showProgress(false)
                view.onDeleteStudent(student, false, "Error : gagal menghapus siswa ${student.name}")
            }, { response ->
                view.showProgress(false)
                if (response?.status == "OK") {
                    view.onDeleteStudent(student, true, "Berhasil menghapus siswa ${student.name}")
                } else {
                    view.onDeleteStudent(student, false, "Error : gagal menghapus siswa ${student.name}")
                }
            })
    }
}
