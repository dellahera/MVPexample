package dekha.mvptrial.UI.newStudent

interface NewStudentView{
    fun onStudentSave(status: Boolean, message: String)
}