package dekha.mvptrial.UI.newStudent

import dekha.mvptrial.BinarMvpApp
import dekha.mvptrial.Model.GeneralResponse
import dekha.mvptrial.Model.Student
import dekha.mvptrial.common.execute
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class NewStudentPresenter(private val view : NewStudentView){

    fun newStudent(studentMap: Map<String, String>) {
        BinarMvpApp.api.newStudent(studentMap)
            .execute({
                view.onStudentSave(false, "Gagal menyimpan siswa, coba lagi")
            }, {
                val isSuccess = it?.status == "OK"
                if (isSuccess)
                    view.onStudentSave(isSuccess, "Sukses menyimpan siswa")
                else
                    view.onStudentSave(isSuccess, "Gagal menyimpan siswa, coba lagi")
            })
    }

    fun editStudent(studentId: Int, map: Map<String, String>) {
        BinarMvpApp.api.editStudent(studentId, map)
            .enqueue(object : Callback<GeneralResponse<Student>> {
                override fun onFailure(call: Call<GeneralResponse<Student>>, t: Throwable) {
                    view.onStudentSave(false, "Gagal mengubah data siswa, coba lagi")
                }

                override fun onResponse(
                    call: Call<GeneralResponse<Student>>,
                    response: Response<GeneralResponse<Student>>
                ) {
                    val isSuccess = response.body()?.status == "OK"
                    if (isSuccess)
                        view.onStudentSave(isSuccess, "Sukses mengubah data siswa")
                    else
                        view.onStudentSave(isSuccess, "Gagal mengubah data siswa, coba lagi")
                }
            })
    }
}