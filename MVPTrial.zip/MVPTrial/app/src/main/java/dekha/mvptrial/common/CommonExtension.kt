package dekha.mvptrial.common

import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

fun <T> Call<T>.execute(onError: (String) -> Unit, onSuccess: (T?) -> Unit) {
    this.enqueue(object : Callback<T> {
        override fun onFailure(call: Call<T>, t: Throwable) {
            onError(t.localizedMessage)
        }

        override fun onResponse(call: Call<T>, response: Response<T>) {
            onSuccess(response.body())
        }
    })
}