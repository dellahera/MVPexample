package dekha.mvptrial.UI.newStudent

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import dekha.mvptrial.Model.Student
import dekha.mvptrial.R
import dekha.mvptrial.common.Constant
import dekha.mvptrial.common.toast
import kotlinx.android.synthetic.main.activity_new_student.*

class FormStudent: AppCompatActivity(), NewStudentView {

    private val presenter = NewStudentPresenter(this)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_new_student)

        setupView()
    }

    private fun setupView() {
        val student: Student? = intent.getParcelableExtra(Constant.STUDENT)
        btnSaveStudent.setOnClickListener {
            validateForm(student)
        }

        edtStudentName.setText(student?.name)
        edtStudentEmail.setText(student?.email)
        edtStudentName.setSelection(edtStudentName.length())
        edtStudentEmail.setSelection(edtStudentEmail.length())
    }

    private fun validateForm(student: Student?) {
        val name = edtStudentName.text.toString()
        val email = edtStudentEmail.text.toString()

        if (name.isBlank() || email.isBlank()) {
            toast("Nama dan email tidak boleh kosong")
            return
        }

        val map = mutableMapOf<String, String>()
        map["name"] = name
        map["email"] = email

        if (student == null) {
            presenter.newStudent(map)
        } else {
            presenter.editStudent(student.id, map)
        }
    }

    override fun onStudentSave(status: Boolean, message: String) {
        toast(message)
        if (status) {
            finish()
        }
    }
}